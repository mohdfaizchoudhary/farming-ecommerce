﻿// "use client";

// import { useEffect, useState } from "react";
// import Link from "next/link";
// import { getCatalogProducts, money, type Product } from "@/lib/catalog";
// import { useStore } from "@/components/StoreProvider";

// export default function Admin() {
//   const [products, setProducts] = useState<Product[]>([]);
//   const { orders } = useStore();

//   useEffect(() => {
//     setProducts(getCatalogProducts());
//   }, []);
//   const businessTotal = orders
//     .filter((order) => order.paymentStatus === "successful")
//     .reduce((sum, order) => sum + order.total, 0);

//   return (
//     <div>
//       <p className="eyebrow">Overview</p>
//       <h1 className="section-title mt-2">Admin Dashboard</h1>
//       <div className="mt-5 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">Admin-only product management is enabled. Only the separate admin account can upload or edit items.</div>
//       <div className="mt-5 rounded-2xl bg-white p-5 sm:max-w-sm"><p className="text-xs text-charcoal/50">Total Business</p><b className="mt-3 block font-serif text-3xl text-forest">{money(businessTotal)}</b><p className="mt-2 text-xs text-charcoal/50">Successful demo payments</p></div>
//       <div className="mt-5 rounded-2xl bg-white p-5">
//         <div className="flex justify-between"><h2 className="font-serif text-xl text-forest">Catalogue Preview</h2><Link href="/admin/products" className="text-xs underline">Manage</Link></div>
//         {products.slice(0, 5).map((product) => <div key={product.id} className="flex flex-wrap justify-between gap-2 border-b border-forest/10 py-3 text-sm"><span>{product.name}<span className="ml-2 text-xs text-charcoal/50">Stock: {product.stock}</span></span><b>{money(product.price)}</b></div>)}
//       </div>
//     </div>
//   );
// }



"use client";

import React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  IndianRupee,
  ShoppingBag,
  Users,
  Package,
  Clock,
  RefreshCw,
  ArrowUpRight,
  Plus,
  PackageCheck,
  CheckCircle2,
} from "lucide-react";

const KPI_CARDS = [
  {
    title: "Total Revenue",
    value: "₹2,84,950",
    change: "+18.4% vs last week",
    icon: IndianRupee,
    accent: "bg-[#123C32] text-[#D9A65A]",
  },
  {
    title: "Total Orders",
    value: "342",
    change: "28 awaiting dispatch",
    icon: ShoppingBag,
    accent: "bg-[#E5EDE6] text-[#123C32]",
  },
  {
    title: "Total Customers",
    value: "1,284",
    change: "+64 new this month",
    icon: Users,
    accent: "bg-[#E5EDE6] text-[#123C32]",
  },
  {
    title: "Active Products",
    value: "86",
    change: "Across 7 categories",
    icon: Package,
    accent: "bg-[#E5EDE6] text-[#123C32]",
  },
  {
    title: "Pending Dispatches",
    value: "14",
    change: "Ready for cold-chain slot",
    icon: Clock,
    accent: "bg-amber-100 text-amber-800",
  },
  {
    title: "Replace Requests",
    value: "3",
    change: "Awaiting admin approval",
    icon: RefreshCw,
    accent: "bg-sky-100 text-sky-800",
  },
];

const RECENT_ORDERS = [
  {
    id: "ORD-2026-1084",
    customer: "Rajesh Verma",
    category: "Farming & Livestock",
    amount: "₹4,250",
    payment: "Razorpay Paid",
    status: "Confirmed",
  },
  {
    id: "ORD-2026-1083",
    customer: "Ananya Sharma",
    category: "Raw Chicken & Meat",
    amount: "₹840",
    payment: "COD",
    status: "Packed",
  },
  {
    id: "ORD-2026-1082",
    customer: "GreenValley Farms",
    category: "Eggs & Egg Foods",
    amount: "₹12,600",
    payment: "Razorpay Paid",
    status: "Shipped",
  },
  {
    id: "ORD-2026-1081",
    customer: "Karan Malhotra",
    category: "Supplements & Care",
    amount: "₹2,699",
    payment: "Razorpay Paid",
    status: "Delivered",
  },
];

const WEEKLY_BARS = [
  { day: "Mon", pct: 55 },
  { day: "Tue", pct: 72 },
  { day: "Wed", pct: 64 },
  { day: "Thu", pct: 88 },
  { day: "Fri", pct: 79 },
  { day: "Sat", pct: 96 },
  { day: "Sun", pct: 84 },
];

export default function AdminDashboardPage() {
  return (
    <div className="space-y-8">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-[0.18em] text-[#123C32]/60">
            Executive Command Center
          </span>
          <h1 className="font-serif text-2xl sm:text-4xl font-bold text-[#123C32] mt-1">
            Dashboard
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/admin/products"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-[#123C32] text-[#F7F5EF] text-xs sm:text-sm font-bold hover:bg-[#1a5244] transition-all shadow-md"
          >
            <Plus className="w-4 h-4 text-[#D9A65A]" /> Add Listing
          </Link>
          <Link
            href="/admin/orders"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white border border-[#123C32]/15 text-[#123C32] text-xs sm:text-sm font-bold hover:bg-[#E5EDE6] transition-all"
          >
            Manage Orders
          </Link>
        </div>
      </div>

      {/* 6 Animated KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
        {KPI_CARDS.map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <motion.div
              key={kpi.title}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.06 }}
              whileHover={{ y: -4 }}
              className="bg-white rounded-3xl p-6 border border-[#123C32]/10 shadow-sm hover:shadow-xl transition-all"
            >
              <div className="flex items-center justify-between">
                <span
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center ${kpi.accent}`}
                >
                  <Icon className="w-5 h-5" />
                </span>
                <ArrowUpRight className="w-4 h-4 text-[#123C32]/40" />
              </div>

              <div className="mt-5">
                <p className="text-xs font-semibold text-[#202824]/60 uppercase tracking-wider">
                  {kpi.title}
                </p>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-[#123C32] mt-1">
                  {kpi.value}
                </h2>
                <p className="text-xs font-medium text-emerald-700 mt-1.5">
                  {kpi.change}
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Middle Analytics & Operational Queue */}
      <div className="grid lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-[#123C32]/10 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-serif text-xl font-bold text-[#123C32]">
                7-Day Order Velocity
              </h3>
              <p className="text-xs text-[#202824]/60">
                Daily fulfilled volume across all 7 categories
              </p>
            </div>
            <span className="px-3 py-1 rounded-full bg-[#E5EDE6] text-[#123C32] text-xs font-bold">
              Live Sync
            </span>
          </div>

          <div className="h-52 flex items-end justify-between gap-3 pt-6 px-2">
            {WEEKLY_BARS.map((bar, i) => (
              <div
                key={bar.day}
                className="flex-1 flex flex-col items-center gap-2 h-full justify-end"
              >
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: `${bar.pct}%` }}
                  transition={{
                    duration: 0.7,
                    delay: i * 0.08,
                    ease: [0.22, 1, 0.36, 1],
                  }}
                  className="w-full max-w-[2.5rem] rounded-t-xl bg-gradient-to-t from-[#123C32] to-[#236b59] hover:from-[#D9A65A] hover:to-[#e6bc7a] transition-colors cursor-pointer relative group"
                >
                  <span className="opacity-0 group-hover:opacity-100 absolute -top-7 left-1/2 -translate-x-1/2 text-[10px] font-bold bg-[#202824] text-white px-2 py-0.5 rounded-md transition-opacity">
                    {bar.pct}%
                  </span>
                </motion.div>
                <span className="text-xs font-bold text-[#202824]/65">
                  {bar.day}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5 bg-[#123C32] text-[#F7F5EF] rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#D9A65A]">
              Live Fulfilment Pulse
            </span>
            <h3 className="font-serif text-2xl font-bold mt-1">
              Dispatch & Replacement Queue
            </h3>

            <div className="mt-6 space-y-3.5">
              {[
                {
                  label: "Pending Replacement Requests",
                  count: "3 Requests",
                  icon: RefreshCw,
                },
                {
                  label: "Ready for Cold-Chain Packing",
                  count: "14 Orders",
                  icon: PackageCheck,
                },
                {
                  label: "Delivered Today",
                  count: "49 Orders",
                  icon: CheckCircle2,
                },
              ].map((row) => (
                <div
                  key={row.label}
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-white/10 border border-white/10"
                >
                  <div className="flex items-center gap-3">
                    <row.icon className="w-4 h-4 text-[#D9A65A]" />
                    <span className="text-xs sm:text-sm font-medium">
                      {row.label}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-[#D9A65A]">
                    {row.count}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <Link
            href="/admin/orders"
            className="mt-6 w-full text-center py-3 rounded-2xl bg-[#D9A65A] text-[#202824] font-bold text-xs sm:text-sm hover:bg-[#e5b56d] transition-colors"
          >
            Open Orders & Replacements →
          </Link>
        </div>
      </div>

      {/* Recent Orders Table */}
      <div className="bg-white rounded-3xl border border-[#123C32]/10 shadow-sm overflow-hidden">
        <div className="p-6 flex items-center justify-between border-b border-[#123C32]/10">
          <h3 className="font-serif text-xl font-bold text-[#123C32]">
            Recent Orders
          </h3>
          <Link
            href="/admin/orders"
            className="text-xs font-bold text-[#123C32] hover:text-[#D9A65A]"
          >
            View All Orders →
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#F7F5EF] text-[11px] font-bold uppercase tracking-wider text-[#123C32]/70">
                <th className="py-3.5 px-6">Order ID</th>
                <th className="py-3.5 px-6">Customer</th>
                <th className="py-3.5 px-6">Category</th>
                <th className="py-3.5 px-6">Amount</th>
                <th className="py-3.5 px-6">Payment</th>
                <th className="py-3.5 px-6">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#123C32]/10 text-sm">
              {RECENT_ORDERS.map((order) => (
                <tr
                  key={order.id}
                  className="hover:bg-[#F7F5EF]/60 transition-colors"
                >
                  <td className="py-4 px-6 font-mono font-bold text-[#123C32]">
                    {order.id}
                  </td>
                  <td className="py-4 px-6 font-semibold">{order.customer}</td>
                  <td className="py-4 px-6 text-xs text-[#202824]/70">
                    {order.category}
                  </td>
                  <td className="py-4 px-6 font-bold">{order.amount}</td>
                  <td className="py-4 px-6 text-xs">{order.payment}</td>
                  <td className="py-4 px-6">
                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#E5EDE6] text-[#123C32]">
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}