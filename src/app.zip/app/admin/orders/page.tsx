// "use client";

// import { useStore, type OrderStatus } from "@/components/StoreProvider";
// import { money } from "@/lib/catalog";

// const statuses: OrderStatus[] = ["placed", "confirmed", "processing", "shipped", "delivered", "cancelled"];
// const paymentMethods = { cod: "Cash on Delivery", upi: "UPI", card: "Credit / Debit Card", unknown: "Not recorded" };

// export default function Page() {
//   const { orders, updateOrderStatus } = useStore();

//   return (
//     <div>
//       <p className="eyebrow">Fulfilment</p>
//       <h1 className="section-title mt-2">Orders</h1>
//       <p className="mt-3 text-sm text-charcoal/60">Demo orders are saved in this browser and sync across its open tabs.</p>
//       <div className="mt-5 space-y-3">
//         {orders.map((order) => (
//           <article key={order.id} className="rounded-2xl bg-white p-5">
//             <div className="flex flex-wrap items-start justify-between gap-4">
//               <div>
//                 <b className="text-forest">{order.id}</b>
//                 <p className="mt-1 text-xs text-charcoal/55">{order.customerName} · {new Date(order.date).toLocaleString()}</p>
//               </div>
//               <b>{money(order.total)}</b>
//             </div>
//             <div className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
//               <p><span className="text-charcoal/55">Payment method:</span> {paymentMethods[order.paymentMethod] ?? "Demo"}</p>
//               <p><span className="text-charcoal/55">Payment status:</span> <span className="capitalize">{order.paymentStatus}</span></p>
//             </div>
//             <div className="mt-4 grid gap-3 rounded-xl bg-sage/60 p-4 text-sm sm:grid-cols-2">
//               <p className="break-all"><span className="text-charcoal/55">Email:</span> {order.customerEmail || "Not recorded"}</p>
//               <p><span className="text-charcoal/55">Phone:</span> {order.customerPhone || "Not recorded"}</p>
//               <p className="whitespace-pre-wrap break-words sm:col-span-2"><span className="text-charcoal/55">Delivery address:</span> {order.customerAddress || "Not recorded"}</p>
//             </div>
//             <ul className="mt-3 space-y-1 text-xs text-charcoal/60">
//               {order.items.map((item, index) => <li key={`${item.name}-${index}`}>{item.name} × {item.quantity}</li>)}
//             </ul>
//             <label className="mt-4 flex flex-wrap items-center gap-3 text-sm font-medium text-forest">
//               Order status
//               <select
//                 className="field max-w-52 capitalize"
//                 value={order.status}
//                 onChange={(event) => updateOrderStatus(order.id, event.target.value as OrderStatus)}
//                 aria-label={`Update status for order ${order.id}`}
//               >
//                 {statuses.map((status) => <option key={status} value={status} className="capitalize">{status}</option>)}
//               </select>
//             </label>
//           </article>
//         ))}
//       </div>
//       {!orders.length && <p className="mt-5 rounded-2xl bg-white p-6 text-sm">No local orders found.</p>}
//     </div>
//   );
// }


"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  Eye,
  CheckCircle2,
  XCircle,
  X,
  MapPin,
  Phone,
  Package,
  RefreshCw,
} from "lucide-react";

type OrderState =
  | "Confirmed"
  | "Processing"
  | "Packed"
  | "Shipped"
  | "Delivered"
  | "Cancelled";

interface AdminOrder {
  id: string;
  date: string;
  customer: string;
  phone: string;
  address: string;
  itemsSummary: string;
  total: number;
  paymentMethod: "Razorpay" | "COD";
  paymentStatus: "Paid" | "Pending";
  status: OrderState;
  isReplacementOrder?: boolean;
}

interface ReplaceRequest {
  id: string;
  originalOrderId: string;
  date: string;
  customer: string;
  phone: string;
  address: string;
  itemsSummary: string;
  total: number;
  reason: string;
  requestStatus: "Pending" | "Rejected";
}

const ORDER_STATUS_OPTIONS: OrderState[] = [
  "Confirmed",
  "Processing",
  "Packed",
  "Shipped",
  "Delivered",
  "Cancelled",
];

const INITIAL_ORDERS: AdminOrder[] = [
  {
    id: "ORD-2026-1084",
    date: "17 Nov 2026, 10:15 AM",
    customer: "Rajesh Verma",
    phone: "+91 98112 34567",
    address: "Plot 42, Mawana Road, Meerut, UP 250001",
    itemsSummary: "Kadaknath Hatching Eggs (2 Trays)",
    total: 1798,
    paymentMethod: "Razorpay",
    paymentStatus: "Paid",
    status: "Confirmed",
  },
  {
    id: "ORD-2026-1083",
    date: "17 Nov 2026, 09:40 AM",
    customer: "Ananya Sharma",
    phone: "+91 98765 11223",
    address: "B-14, Shastri Nagar, Meerut, UP 250004",
    itemsSummary: "Chicken Breast 500g (2 Packs), Brown Eggs (12)",
    total: 827,
    paymentMethod: "COD",
    paymentStatus: "Pending",
    status: "Packed",
  },
  {
    id: "ORD-2026-1082",
    date: "16 Nov 2026, 06:20 PM",
    customer: "GreenValley Poultry Farm",
    phone: "+91 99100 88776",
    address: "NH-58 Agri Zone, Muzaffarnagar, UP",
    itemsSummary: "Vaccinated Day-Old Chicks (Box of 100)",
    total: 7400,
    paymentMethod: "Razorpay",
    paymentStatus: "Paid",
    status: "Shipped",
  },
];

const INITIAL_REPLACE_REQUESTS: ReplaceRequest[] = [
  {
    id: "RPL-2026-019",
    originalOrderId: "ORD-2026-1071",
    date: "17 Nov 2026, 11:05 AM",
    customer: "Vikram Singh",
    phone: "+91 97110 55432",
    address: "Civil Lines, Meerut, UP 250001",
    itemsSummary: "Free-Range Brown Eggs (30 Tray)",
    total: 449,
    reason: "4 eggs cracked during transit; photo verified.",
    requestStatus: "Pending",
  },
  {
    id: "RPL-2026-018",
    originalOrderId: "ORD-2026-1065",
    date: "16 Nov 2026, 04:30 PM",
    customer: "Neha Gupta",
    phone: "+91 98180 22991",
    address: "Saket Colony, Meerut, UP 250003",
    itemsSummary: "Herb & Garlic Chicken Seekh Kebabs (500g)",
    total: 265,
    reason: "Outer vacuum seal loose upon arrival.",
    requestStatus: "Pending",
  },
];

export default function AdminOrdersPage() {
  const [activeTab, setActiveTab] = useState<"orders" | "replacements">("orders");
  const [orders, setOrders] = useState<AdminOrder[]>(INITIAL_ORDERS);
  const [replaceRequests, setReplaceRequests] = useState<ReplaceRequest[]>(
    INITIAL_REPLACE_REQUESTS
  );

  const [statusFilter, setStatusFilter] = useState("All");
  const [search, setSearch] = useState("");
  const [selectedOrder, setSelectedOrder] = useState<AdminOrder | null>(null);
  const [selectedReplace, setSelectedReplace] = useState<ReplaceRequest | null>(
    null
  );

  const filteredOrders = orders.filter((o) => {
    const matchStatus = statusFilter === "All" || o.status === statusFilter;
    const matchQuery =
      o.id.toLowerCase().includes(search.toLowerCase()) ||
      o.customer.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchQuery;
  });

  const handleStatusChange = (orderId: string, newStatus: OrderState) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: newStatus } : o))
    );
    if (selectedOrder?.id === orderId) {
      setSelectedOrder((prev) => (prev ? { ...prev, status: newStatus } : null));
    }
  };

  // Approve replacement -> Moves into main Orders list as Confirmed & switches to Orders view
  const handleApproveReplacement = (req: ReplaceRequest) => {
    const newReplacementOrder: AdminOrder = {
      id: `${req.originalOrderId}-RPL`,
      date: "Approved Just Now",
      customer: req.customer,
      phone: req.phone,
      address: req.address,
      itemsSummary: `[Replacement] ${req.itemsSummary}`,
      total: 0,
      paymentMethod: "Razorpay",
      paymentStatus: "Paid",
      status: "Confirmed",
      isReplacementOrder: true,
    };

    setOrders((prev) => [newReplacementOrder, ...prev]);
    setReplaceRequests((prev) => prev.filter((r) => r.id !== req.id));
    setSelectedReplace(null);
    setActiveTab("orders");
  };

  const handleRejectReplacement = (reqId: string) => {
    setReplaceRequests((prev) =>
      prev.map((r) =>
        r.id === reqId ? { ...r, requestStatus: "Rejected" } : r
      )
    );
    setSelectedReplace(null);
  };

  return (
    <div className="space-y-6">
      {/* Header + Main Section Switcher (Orders vs Replace Requests) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-[0.18em] text-[#123C32]/60">
            Fulfilment & Returns
          </span>
          <h1 className="font-serif text-2xl sm:text-4xl font-bold text-[#123C32] mt-1">
            Orders & Replacement Queue
          </h1>
        </div>

        <div className="inline-flex p-1.5 rounded-2xl bg-white border border-[#123C32]/15 shadow-sm self-start">
          <button
            onClick={() => setActiveTab("orders")}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === "orders"
                ? "bg-[#123C32] text-[#F7F5EF] shadow-sm"
                : "text-[#202824]/70 hover:text-[#123C32]"
            }`}
          >
            All Orders ({orders.length})
          </button>
          <button
            onClick={() => setActiveTab("replacements")}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all ${
              activeTab === "replacements"
                ? "bg-[#123C32] text-[#F7F5EF] shadow-sm"
                : "text-[#202824]/70 hover:text-[#123C32]"
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5 text-[#D9A65A]" />
            Replace Requests (
            {replaceRequests.filter((r) => r.requestStatus === "Pending").length})
          </button>
        </div>
      </div>

      {activeTab === "orders" ? (
        <>
          {/* Status Filter Pills + Search */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-4 rounded-3xl border border-[#123C32]/10 shadow-sm">
            <div className="flex flex-wrap gap-1.5">
              {["All", ...ORDER_STATUS_OPTIONS].map((st) => (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    statusFilter === st
                      ? "bg-[#123C32] text-[#F7F5EF]"
                      : "bg-[#F7F5EF] text-[#202824]/75 hover:bg-[#E5EDE6]"
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            <div className="relative w-full lg:w-72">
              <Search className="w-4 h-4 text-[#123C32]/45 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Order ID or customer..."
                className="w-full pl-10 pr-4 py-2 rounded-xl bg-[#F7F5EF] text-xs sm:text-sm focus:outline-none"
              />
            </div>
          </div>

          {/* Orders Table */}
          <div className="bg-white rounded-3xl border border-[#123C32]/10 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#F7F5EF] text-[11px] font-bold uppercase tracking-wider text-[#123C32]/70">
                    <th className="py-4 px-5">Order #</th>
                    <th className="py-4 px-5">Customer</th>
                    <th className="py-4 px-5">Items</th>
                    <th className="py-4 px-5">Total & Payment</th>
                    <th className="py-4 px-5">Current Status</th>
                    <th className="py-4 px-5 text-right">Manage</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#123C32]/10 text-sm">
                  {filteredOrders.map((order) => (
                    <tr
                      key={order.id}
                      className="hover:bg-[#F7F5EF]/50 transition-colors"
                    >
                      <td className="py-4 px-5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-[#123C32]">
                            {order.id}
                          </span>
                          {order.isReplacementOrder && (
                            <span className="px-2 py-0.5 rounded-md bg-sky-100 text-sky-800 text-[10px] font-extrabold uppercase">
                              Replacement
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-[#202824]/55">
                          {order.date}
                        </span>
                      </td>

                      <td className="py-4 px-5">
                        <span className="font-bold text-[#202824] block">
                          {order.customer}
                        </span>
                        <span className="text-xs text-[#202824]/60">
                          {order.phone}
                        </span>
                      </td>

                      <td className="py-4 px-5 text-xs text-[#202824]/80 max-w-xs">
                        {order.itemsSummary}
                      </td>

                      <td className="py-4 px-5">
                        <span className="font-extrabold text-[#123C32] block">
                          {order.isReplacementOrder
                            ? "₹0 (Covered)"
                            : `₹${order.total.toLocaleString("en-IN")}`}
                        </span>
                        <span className="text-[11px] font-semibold text-emerald-700">
                          {order.paymentMethod} • {order.paymentStatus}
                        </span>
                      </td>

                      <td className="py-4 px-5">
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-bold ${
                            order.status === "Cancelled"
                              ? "bg-rose-100 text-rose-700"
                              : order.status === "Delivered"
                              ? "bg-emerald-100 text-emerald-800"
                              : "bg-[#E5EDE6] text-[#123C32]"
                          }`}
                        >
                          {order.status}
                        </span>
                      </td>

                      <td className="py-4 px-5 text-right">
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#123C32] text-[#F7F5EF] text-xs font-bold hover:bg-[#D9A65A] hover:text-[#202824] transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" /> Manage
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        /* REPLACEMENT REQUESTS TABLE */
        <div className="bg-white rounded-3xl border border-[#123C32]/10 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#F7F5EF] text-[11px] font-bold uppercase tracking-wider text-[#123C32]/70">
                  <th className="py-4 px-5">Request / Original Order</th>
                  <th className="py-4 px-5">Customer</th>
                  <th className="py-4 px-5">Item & Reason</th>
                  <th className="py-4 px-5">Status</th>
                  <th className="py-4 px-5 text-right">Decision</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#123C32]/10 text-sm">
                {replaceRequests.map((req) => (
                  <tr
                    key={req.id}
                    className="hover:bg-[#F7F5EF]/50 transition-colors"
                  >
                    <td className="py-4 px-5">
                      <span className="font-mono font-bold text-[#123C32] block">
                        {req.id}
                      </span>
                      <span className="text-xs text-[#202824]/60">
                        Ref: {req.originalOrderId}
                      </span>
                    </td>

                    <td className="py-4 px-5">
                      <span className="font-bold text-[#202824] block">
                        {req.customer}
                      </span>
                      <span className="text-xs text-[#202824]/60">
                        {req.phone}
                      </span>
                    </td>

                    <td className="py-4 px-5 max-w-xs">
                      <span className="font-semibold text-xs text-[#123C32] block">
                        {req.itemsSummary}
                      </span>
                      <span className="text-xs text-[#202824]/70">
                        Reason: {req.reason}
                      </span>
                    </td>

                    <td className="py-4 px-5">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold ${
                          req.requestStatus === "Rejected"
                            ? "bg-rose-100 text-rose-700"
                            : "bg-amber-100 text-amber-800"
                        }`}
                      >
                        {req.requestStatus}
                      </span>
                    </td>

                    <td className="py-4 px-5 text-right">
                      {req.requestStatus === "Pending" ? (
                        <div className="inline-flex items-center gap-2">
                          <button
                            onClick={() => handleApproveReplacement(req)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                          </button>
                          <button
                            onClick={() => handleRejectReplacement(req.id)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white text-xs font-bold transition-colors"
                          >
                            <XCircle className="w-3.5 h-3.5" /> Reject
                          </button>
                          <button
                            onClick={() => setSelectedReplace(req)}
                            className="p-2 rounded-xl bg-[#F7F5EF] text-[#123C32] hover:bg-[#E5EDE6]"
                            aria-label="Inspect replacement"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs text-[#202824]/50">
                          Closed
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ORDER MANAGE DRAWER (With Status Dropdown: Confirmed, Processing, Packed, Shipped, Delivered, Cancelled) */}
      <AnimatePresence>
        {selectedOrder && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedOrder(null)}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 260 }}
              className="fixed inset-y-0 right-0 w-full max-w-md bg-[#F7F5EF] p-6 sm:p-8 z-50 shadow-2xl overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-4 border-b border-[#123C32]/10">
                <div>
                  <span className="text-xs font-mono font-bold text-[#D9A65A] bg-[#123C32] px-2.5 py-0.5 rounded-md">
                    {selectedOrder.id}
                  </span>
                  <h2 className="font-serif text-2xl font-bold text-[#123C32] mt-1">
                    Manage Order
                  </h2>
                </div>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="p-2 rounded-full bg-[#E5EDE6] text-[#123C32]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-6 space-y-5">
                <div className="p-4 rounded-2xl bg-white border border-[#123C32]/10 space-y-2">
                  <p className="font-bold text-[#123C32]">
                    {selectedOrder.customer}
                  </p>
                  <p className="text-xs text-[#202824]/70 flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-[#123C32]" />{" "}
                    {selectedOrder.phone}
                  </p>
                  <p className="text-xs text-[#202824]/70 flex items-start gap-2">
                    <MapPin className="w-3.5 h-3.5 text-[#123C32] shrink-0 mt-0.5" />
                    {selectedOrder.address}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-[#123C32]/10 space-y-2">
                  <span className="text-[11px] font-bold uppercase text-[#123C32]/60 flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5" /> Ordered Snapshot
                  </span>
                  <p className="text-sm font-semibold text-[#202824]">
                    {selectedOrder.itemsSummary}
                  </p>
                  <p className="text-lg font-extrabold text-[#123C32] pt-1">
                    Total: ₹{selectedOrder.total.toLocaleString("en-IN")} (
                    {selectedOrder.paymentMethod})
                  </p>
                </div>

                {/* CURRENT STATUS CARD WITH DROPDOWN */}
                <div className="p-5 rounded-2xl bg-[#123C32] text-[#F7F5EF] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs uppercase tracking-wider text-[#D9A65A] font-bold">
                      Current Status
                    </span>
                    <span className="px-3 py-1 rounded-full bg-white/15 text-xs font-bold">
                      {selectedOrder.status}
                    </span>
                  </div>

                  <div className="pt-2">
                    <label className="block text-xs text-white/75 mb-1.5">
                      Update Order Status
                    </label>
                    <select
                      value={selectedOrder.status}
                      onChange={(e) =>
                        handleStatusChange(
                          selectedOrder.id,
                          e.target.value as OrderState
                        )
                      }
                      className="w-full px-4 py-3 rounded-xl bg-white text-[#123C32] font-bold text-sm focus:outline-none cursor-pointer"
                    >
                      {ORDER_STATUS_OPTIONS.map((opt) => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* REPLACEMENT REQUEST INSPECT DRAWER */}
      <AnimatePresence>
        {selectedReplace && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedReplace(null)}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 260 }}
              className="fixed inset-y-0 right-0 w-full max-w-md bg-[#F7F5EF] p-6 sm:p-8 z-50 shadow-2xl overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-4 border-b border-[#123C32]/10">
                <div>
                  <span className="text-xs font-mono font-bold text-[#D9A65A] bg-[#123C32] px-2.5 py-0.5 rounded-md">
                    {selectedReplace.id}
                  </span>
                  <h2 className="font-serif text-2xl font-bold text-[#123C32] mt-1">
                    Replacement Review
                  </h2>
                </div>
                <button
                  onClick={() => setSelectedReplace(null)}
                  className="p-2 rounded-full bg-[#E5EDE6] text-[#123C32]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-6 space-y-5">
                <div className="p-4 rounded-2xl bg-white border border-[#123C32]/10 space-y-2">
                  <p className="font-bold text-[#123C32]">
                    {selectedReplace.customer}
                  </p>
                  <p className="text-xs text-[#202824]/70">
                    Original Order: {selectedReplace.originalOrderId}
                  </p>
                  <p className="text-xs text-[#202824]/70">
                    {selectedReplace.address}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-[#123C32]/10 space-y-2">
                  <span className="text-[11px] font-bold uppercase text-[#123C32]/60">
                    Customer Reason
                  </span>
                  <p className="text-sm font-semibold text-[#202824]">
                    {selectedReplace.itemsSummary}
                  </p>
                  <p className="text-xs text-rose-700 bg-rose-50 p-3 rounded-xl">
                    “{selectedReplace.reason}”
                  </p>
                </div>

                <div className="p-5 rounded-2xl bg-[#123C32] text-[#F7F5EF] space-y-3">
                  <p className="text-xs text-white/80">
                    Approving will create a Confirmed replacement dispatch order
                    in the main Orders list.
                  </p>
                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <button
                      onClick={() => handleApproveReplacement(selectedReplace)}
                      className="py-3 rounded-xl bg-[#D9A65A] text-[#202824] font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-[#e5b56d]"
                    >
                      <CheckCircle2 className="w-4 h-4" /> Approve & Move
                    </button>
                    <button
                      onClick={() =>
                        handleRejectReplacement(selectedReplace.id)
                      }
                      className="py-3 rounded-xl bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-rose-600"
                    >
                      <XCircle className="w-4 h-4" /> Reject Request
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}