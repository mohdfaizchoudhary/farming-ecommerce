// "use client";

// import { useEffect, useMemo, useState } from "react";
// import { categories, createProductId, getCatalogProducts, money, saveCatalogProducts, type Product } from "@/lib/catalog";
// import ProductImage from "@/components/ProductImage";

// const emptyForm = {
//   name: "",
//   category: "poultry-buy-sell",
//   price: "",
//   mrp: "",
//   unit: "",
//   description: "",
//   image: "",
//   stock: "",
// };

// export default function Page() {
//   const [products, setProducts] = useState<Product[]>([]);
//   const [editingId, setEditingId] = useState<string | null>(null);
//   const [form, setForm] = useState(emptyForm);
//   const [message, setMessage] = useState("");

//   useEffect(() => {
//     setProducts(getCatalogProducts());
//   }, []);

//   const normalizedProducts = useMemo(() => products, [products]);

//   function setField<K extends keyof typeof emptyForm>(field: K, value: (typeof emptyForm)[K]) {
//     setForm((current) => ({ ...current, [field]: value }));
//   }

//   function resetForm() {
//     setEditingId(null);
//     setForm(emptyForm);
//   }

//   function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
//     event.preventDefault();

//     const id = editingId ?? createProductId(form.name || "product");
//     const baseSlug = (form.name || "product").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "product";
//     const slug = normalizedProducts.some((product) => product.id !== id && product.slug === baseSlug)
//       ? `${baseSlug}-${id}`
//       : baseSlug;
//     const nextProduct: Product = {
//       id,
//       slug,
//       name: form.name.trim(),
//       category: form.category,
//       price: Number(form.price),
//       mrp: Number(form.mrp || form.price),
//       unit: form.unit.trim() || "Unit",
//       description: form.description.trim() || "Poultry listing prepared for review.",
//       image: form.image.trim() || "https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=900&q=85",
//       stock: Number(form.stock || 0),
//     };

//     if (!nextProduct.name || Number.isNaN(nextProduct.price) || Number.isNaN(nextProduct.stock)) {
//       setMessage("Please provide a valid product name, price and stock quantity.");
//       return;
//     }
//     if (!categories.some((category) => category.slug === nextProduct.category)) {
//       setMessage("Please select a valid poultry marketplace category.");
//       return;
//     }

//     const nextProducts = editingId
//       ? normalizedProducts.map((product) => (product.id === editingId ? { ...product, ...nextProduct, id: editingId } : product))
//       : [nextProduct, ...normalizedProducts];

//     setProducts(nextProducts);
//     saveCatalogProducts(nextProducts);
//     setMessage(editingId ? "Product updated successfully." : "Product uploaded successfully.");
//     resetForm();
//   }

//   function handleEdit(product: Product) {
//     setEditingId(product.id);
//     setForm({
//       name: product.name,
//       category: product.category,
//       price: String(product.price),
//       mrp: String(product.mrp),
//       unit: product.unit,
//       description: product.description,
//       image: product.image,
//       stock: String(product.stock),
//     });
//   }

//   function handleDelete(productId: string) {
//     const nextProducts = normalizedProducts.filter((product) => product.id !== productId);
//     setProducts(nextProducts);
//     saveCatalogProducts(nextProducts);
//     setMessage("Product removed from the catalogue.");
//     if (editingId === productId) resetForm();
//   }

//   return (
//     <div className="space-y-6">
//       <div>
//         <p className="eyebrow">Poultry marketplace</p>
//         <h1 className="section-title mt-2">Listings</h1>
//       </div>

//       <form onSubmit={handleSubmit} className="rounded-2xl border border-[#dce6df] bg-white p-4 shadow-sm sm:p-6">
//         <div className="flex flex-wrap items-center justify-between gap-3">
//           <h2 className="font-serif text-2xl text-forest">{editingId ? "Edit product" : "Add product"}</h2>
//           {editingId && (
//             <button type="button" onClick={resetForm} className="text-xs font-medium text-charcoal/60 underline">
//               Cancel edit
//             </button>
//           )}
//         </div>

//         <div className="mt-5 grid gap-4 md:grid-cols-2">
//           <label className="block text-sm font-medium text-forest">
//             Product name
//             <input className="field mt-2" value={form.name} onChange={(event) => setField("name", event.target.value)} required />
//           </label>

//           <label className="block text-sm font-medium text-forest">
//             Category
//             <select className="field mt-2" value={form.category} onChange={(event) => setField("category", event.target.value)} required>
//               {categories.map((category) => (
//                 <option key={category.slug} value={category.slug}>
//                   {category.name}
//                 </option>
//               ))}
//             </select>
//           </label>

//           <label className="block text-sm font-medium text-forest">
//             Selling price
//             <input className="field mt-2" type="number" min="0" value={form.price} onChange={(event) => setField("price", event.target.value)} required />
//           </label>

//           <label className="block text-sm font-medium text-forest">
//             MRP
//             <input className="field mt-2" type="number" min="0" value={form.mrp} onChange={(event) => setField("mrp", event.target.value)} required />
//           </label>

//           <label className="block text-sm font-medium text-forest">
//             Unit
//             <input className="field mt-2" value={form.unit} onChange={(event) => setField("unit", event.target.value)} required />
//           </label>

//           <label className="block text-sm font-medium text-forest">
//             Stock
//             <input className="field mt-2" type="number" min="0" value={form.stock} onChange={(event) => setField("stock", event.target.value)} required />
//           </label>

//           <label className="block text-sm font-medium text-forest md:col-span-2">
//             Image URL
//             <input className="field mt-2" type="url" value={form.image} onChange={(event) => setField("image", event.target.value)} required />
//           </label>

//           <label className="block text-sm font-medium text-forest md:col-span-2">
//             Description
//             <textarea className="field mt-2 min-h-28" value={form.description} onChange={(event) => setField("description", event.target.value)} required />
//           </label>
//         </div>

//         <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
//           <button type="submit" className="btn-primary">{editingId ? "Save changes" : "Publish listing"}</button>
//           {message && <p className="text-sm text-forest">{message}</p>}
//         </div>
//       </form>

//       <div className="overflow-x-auto rounded-2xl bg-white">
//         <table className="w-full min-w-[880px] text-left text-sm">
//           <thead className="bg-sage text-forest">
//             <tr>
//               {['Listing', 'Category', 'Reference', 'Price', 'Quantity', 'Actions'].map((heading) => (
//                 <th key={heading} className="p-4 font-semibold">
//                   {heading}
//                 </th>
//               ))}
//             </tr>
//           </thead>
//           <tbody>
//             {normalizedProducts.map((product) => (
//               <tr key={product.id} className="border-t border-forest/10 align-top">
//                 <td className="p-4">
//                   <div className="flex items-center gap-3">
//                     <ProductImage src={product.image} alt={product.name} className="h-12 w-12 rounded-xl object-cover" />
//                     <span>{product.name}</span>
//                   </div>
//                 </td>
//                 <td className="p-4">{categories.find((category) => category.slug === product.category)?.name ?? "Poultry listing"}</td>
//                 <td className="p-4">{product.id.toUpperCase()}</td>
//                 <td className="p-4">{money(product.price)}</td>
//                 <td className="p-4">{product.stock}</td>
//                 <td className="p-4">
//                   <div className="flex gap-2">
//                     <button type="button" onClick={() => handleEdit(product)} className="rounded-full bg-sage px-3 py-1.5 text-xs font-medium text-forest">
//                       Edit
//                     </button>
//                     <button type="button" onClick={() => handleDelete(product.id)} className="rounded-full bg-rose-100 px-3 py-1.5 text-xs font-medium text-rose-700">
//                       Delete
//                     </button>
//                   </div>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// }



"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Plus,
  Search,
  Package,
  AlertTriangle,
  CheckCircle2,
  Edit3,
  Trash2,
  X,
  ImagePlus,
  Snowflake,
  ShieldCheck,
} from "lucide-react";

interface AdminProduct {
  id: string;
  name: string;
  category: string;
  imageUrl: string;
  packSize: string;
  variantType: string;
  description: string;
  price: number;
  mrp: number;
  stock: number;
  handling: "Cold-Chain" | "Live Certified" | "Standard";
  published: boolean;
}

const INITIAL_PRODUCTS: AdminProduct[] = [
  {
    id: "p1",
    name: "Purebred Kadaknath Hatching Eggs",
    category: "Farming & Livestock",
    imageUrl:
      "https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?auto=format&fit=crop&w=400&q=80",
    packSize: "12 Eggs Tray",
    variantType: "Fertile Hatching Grade",
    description:
      "Farm-certified fertile Kadaknath hatching eggs with high hatchability.",
    price: 899,
    mrp: 1200,
    stock: 42,
    handling: "Live Certified",
    published: true,
  },
  {
    id: "p2",
    name: "Antibiotic-Free Skinless Chicken Breast",
    category: "Raw Chicken & Meat",
    imageUrl:
      "https://images.unsplash.com/photo-1604503468506-a8da13d82791?auto=format&fit=crop&w=400&q=80",
    packSize: "500g Chilled Pack",
    variantType: "Boneless Fillet",
    description:
      "Freshly trimmed skinless chicken breast kept at 0–4°C cold chain.",
    price: 319,
    mrp: 380,
    stock: 9,
    handling: "Cold-Chain",
    published: true,
  },
  {
    id: "p3",
    name: "Free-Range Omega-3 Farm Brown Eggs",
    category: "Eggs & Egg Foods",
    imageUrl:
      "https://images.unsplash.com/photo-1506976785307-8732e854ad03?auto=format&fit=crop&w=400&q=80",
    packSize: "30 Eggs Tray",
    variantType: "Free-Range Organic",
    description: "Nutrient-dense brown table eggs from pasture-raised hens.",
    price: 449,
    mrp: 540,
    stock: 68,
    handling: "Standard",
    published: true,
  },
];

export default function AdminProductsPage() {
  const [products, setProducts] = useState<AdminProduct[]>(INITIAL_PRODUCTS);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");

  // Drawer & Edit state
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);

  // Form fields
  const [formName, setFormName] = useState("");
  const [formCategory, setFormCategory] = useState("Farming & Livestock");
  const [formImageUrl, setFormImageUrl] = useState("");
  const [formPackSize, setFormPackSize] = useState("");
  const [formVariantType, setFormVariantType] = useState("");
  const [formDescription, setFormDescription] = useState("");
  const [formPrice, setFormPrice] = useState("");
  const [formMrp, setFormMrp] = useState("");
  const [formStock, setFormStock] = useState("");
  const [formHandling, setFormHandling] =
    useState<AdminProduct["handling"]>("Live Certified");

  const filtered = products.filter((p) => {
    const matchSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.packSize.toLowerCase().includes(search.toLowerCase()) ||
      p.variantType.toLowerCase().includes(search.toLowerCase());
    const matchCat = categoryFilter === "All" || p.category === categoryFilter;
    return matchSearch && matchCat;
  });

  const openAddDrawer = () => {
    setEditingProductId(null);
    setFormName("");
    setFormCategory("Farming & Livestock");
    setFormImageUrl("");
    setFormPackSize("");
    setFormVariantType("");
    setFormDescription("");
    setFormPrice("");
    setFormMrp("");
    setFormStock("");
    setFormHandling("Live Certified");
    setDrawerOpen(true);
  };

  const openEditDrawer = (product: AdminProduct) => {
    setEditingProductId(product.id);
    setFormName(product.name);
    setFormCategory(product.category);
    setFormImageUrl(product.imageUrl);
    setFormPackSize(product.packSize);
    setFormVariantType(product.variantType);
    setFormDescription(product.description);
    setFormPrice(String(product.price));
    setFormMrp(String(product.mrp));
    setFormStock(String(product.stock));
    setFormHandling(product.handling);
    setDrawerOpen(true);
  };

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const previewUrl = URL.createObjectURL(file);
    setFormImageUrl(previewUrl);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const payload: AdminProduct = {
      id: editingProductId || `p-${Date.now()}`,
      name: formName,
      category: formCategory,
      imageUrl:
        formImageUrl ||
        "https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?auto=format&fit=crop&w=400&q=80",
      packSize: formPackSize || "Standard Pack",
      variantType: formVariantType || "Regular",
      description: formDescription,
      price: Number(formPrice) || 499,
      mrp: Number(formMrp) || 599,
      stock: Number(formStock) || 20,
      handling: formHandling,
      published: true,
    };

    if (editingProductId) {
      setProducts((prev) =>
        prev.map((p) => (p.id === editingProductId ? payload : p))
      );
    } else {
      setProducts((prev) => [payload, ...prev]);
    }
    setDrawerOpen(false);
  };

  const togglePublish = (id: string) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, published: !p.published } : p))
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-[0.18em] text-[#123C32]/60">
            Catalogue & Inventory Control
          </span>
          <h1 className="font-serif text-2xl sm:text-4xl font-bold text-[#123C32] mt-1">
            Products & Inventory
          </h1>
        </div>

        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          onClick={openAddDrawer}
          className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-[#123C32] text-[#F7F5EF] text-xs sm:text-sm font-bold shadow-md hover:bg-[#1a5244] transition-all"
        >
          <Plus className="w-4 h-4 text-[#D9A65A]" /> Add New Product
        </motion.button>
      </div>

      {/* Filters & Search */}
      <div className="bg-white p-4 rounded-3xl border border-[#123C32]/10 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 shadow-sm">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-[#123C32]/45 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by product name, pack size or variant..."
            className="w-full pl-11 pr-4 py-2.5 rounded-2xl bg-[#F7F5EF] text-sm focus:outline-none"
          />
        </div>

        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="px-4 py-2.5 rounded-2xl bg-[#F7F5EF] border border-[#123C32]/10 text-sm font-semibold text-[#123C32]"
        >
          <option value="All">All 7 Categories</option>
          <option value="Farming & Livestock">Farming & Livestock</option>
          <option value="Eggs & Egg Foods">Eggs & Egg Foods</option>
          <option value="Ready-to-Cook">Ready-to-Cook</option>
          <option value="Raw Chicken & Meat">Raw Chicken & Meat</option>
          <option value="Supplements & Care">Supplements & Care</option>
          <option value="Skincare & Beauty">Skincare & Beauty</option>
          <option value="Pet Care">Pet Care</option>
        </select>
      </div>

      {/* Product Table */}
      <div className="bg-white rounded-3xl border border-[#123C32]/10 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#F7F5EF] text-[11px] font-bold uppercase tracking-wider text-[#123C32]/70">
                <th className="py-4 px-5">Product & Pack</th>
                <th className="py-4 px-5">Category & Handling</th>
                <th className="py-4 px-5">Price / MRP</th>
                <th className="py-4 px-5">Available Stock</th>
                <th className="py-4 px-5">Status</th>
                <th className="py-4 px-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#123C32]/10 text-sm">
              {filtered.map((item, idx) => (
                <motion.tr
                  key={item.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.04 }}
                  className="hover:bg-[#F7F5EF]/50 transition-colors"
                >
                  <td className="py-4 px-5">
                    <div className="flex items-center gap-3.5">
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-12 h-12 rounded-xl object-cover bg-[#E5EDE6] shrink-0 border border-[#123C32]/10"
                      />
                      <div>
                        <p className="font-bold text-[#123C32]">{item.name}</p>
                        <span className="text-xs text-[#202824]/60">
                          {item.packSize} • {item.variantType}
                        </span>
                      </div>
                    </div>
                  </td>

                  <td className="py-4 px-5">
                    <span className="block text-xs font-semibold text-[#202824]">
                      {item.category}
                    </span>
                    <span className="mt-1 inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-[#E5EDE6] text-[#123C32]">
                      {item.handling === "Cold-Chain" ? (
                        <Snowflake className="w-3 h-3 text-sky-600" />
                      ) : (
                        <ShieldCheck className="w-3 h-3 text-[#123C32]" />
                      )}
                      {item.handling}
                    </span>
                  </td>

                  <td className="py-4 px-5">
                    <span className="font-extrabold text-[#123C32]">
                      ₹{item.price.toLocaleString("en-IN")}
                    </span>
                    <span className="block text-xs text-[#202824]/45 line-through">
                      ₹{item.mrp.toLocaleString("en-IN")}
                    </span>
                  </td>

                  <td className="py-4 px-5">
                    <div className="flex items-center gap-1.5">
                      {item.stock <= 10 ? (
                        <AlertTriangle className="w-4 h-4 text-amber-600" />
                      ) : (
                        <Package className="w-4 h-4 text-emerald-600" />
                      )}
                      <span
                        className={`font-bold ${
                          item.stock <= 10 ? "text-amber-700" : "text-[#202824]"
                        }`}
                      >
                        {item.stock} units
                      </span>
                    </div>
                  </td>

                  <td className="py-4 px-5">
                    <button
                      onClick={() => togglePublish(item.id)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-colors ${
                        item.published
                          ? "bg-emerald-100 text-emerald-800"
                          : "bg-gray-200 text-gray-700"
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {item.published ? "Published" : "Draft"}
                    </button>
                  </td>

                  <td className="py-4 px-5 text-right">
                    <div className="inline-flex items-center gap-2">
                      <button
                        onClick={() => openEditDrawer(item)}
                        aria-label="Edit product"
                        className="p-2 rounded-xl bg-[#F7F5EF] hover:bg-[#123C32] hover:text-white text-[#123C32] transition-colors"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() =>
                          setProducts((prev) =>
                            prev.filter((p) => p.id !== item.id)
                          )
                        }
                        aria-label="Delete product"
                        className="p-2 rounded-xl bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-600 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Slide-Over Form Drawer */}
      <AnimatePresence>
        {drawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDrawerOpen(false)}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 260 }}
              className="fixed inset-y-0 right-0 w-full max-w-lg bg-[#F7F5EF] p-6 sm:p-8 z-50 shadow-2xl overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-4 border-b border-[#123C32]/10">
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#D9A65A] bg-[#123C32] px-2.5 py-0.5 rounded-md">
                    {editingProductId ? "Edit Mode" : "New Listing"}
                  </span>
                  <h2 className="font-serif text-2xl font-bold text-[#123C32] mt-1">
                    {editingProductId
                      ? "Edit Product Details"
                      : "Add New Product"}
                  </h2>
                </div>
                <button
                  onClick={() => setDrawerOpen(false)}
                  className="p-2 rounded-full bg-[#E5EDE6] text-[#123C32]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveProduct} className="mt-6 space-y-4">
                {/* Product Image Upload + Preview */}
                <div>
                  <label className="text-xs font-bold uppercase text-[#123C32] block mb-1.5">
                    Product Image
                  </label>
                  <div className="flex items-center gap-4 p-3.5 rounded-2xl bg-white border border-dashed border-[#123C32]/25">
                    {formImageUrl ? (
                      <img
                        src={formImageUrl}
                        alt="Preview"
                        className="w-16 h-16 rounded-xl object-cover shrink-0 border border-[#123C32]/10"
                      />
                    ) : (
                      <div className="w-16 h-16 rounded-xl bg-[#E5EDE6] text-[#123C32] flex items-center justify-center shrink-0">
                        <ImagePlus className="w-6 h-6" />
                      </div>
                    )}

                    <div className="flex-1 space-y-2">
                      <label className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-[#123C32] text-[#F7F5EF] text-xs font-bold cursor-pointer hover:bg-[#1a5244]">
                        <ImagePlus className="w-3.5 h-3.5 text-[#D9A65A]" />
                        Upload Image File
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageFileChange}
                          className="hidden"
                        />
                      </label>
                      <input
                        type="text"
                        value={formImageUrl}
                        onChange={(e) => setFormImageUrl(e.target.value)}
                        placeholder="Or paste image URL (https://...)"
                        className="w-full px-3 py-1.5 rounded-lg bg-[#F7F5EF] text-xs border border-[#123C32]/10 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Product Title */}
                <div>
                  <label className="text-xs font-bold uppercase text-[#123C32] block mb-1">
                    Product Name
                  </label>
                  <input
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Vaccinated Layer Chicks (Box of 25)"
                    className="w-full px-4 py-3 rounded-xl bg-white border border-[#123C32]/15 text-sm"
                  />
                </div>

                {/* Category & Handling Type */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold uppercase text-[#123C32] block mb-1">
                      Category
                    </label>
                    <select
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value)}
                      className="w-full px-3 py-3 rounded-xl bg-white border border-[#123C32]/15 text-sm"
                    >
                      <option>Farming & Livestock</option>
                      <option>Eggs & Egg Foods</option>
                      <option>Ready-to-Cook</option>
                      <option>Raw Chicken & Meat</option>
                      <option>Supplements & Care</option>
                      <option>Skincare & Beauty</option>
                      <option>Pet Care</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold uppercase text-[#123C32] block mb-1">
                      Handling Type
                    </label>
                    <select
                      value={formHandling}
                      onChange={(e) =>
                        setFormHandling(
                          e.target.value as AdminProduct["handling"]
                        )
                      }
                      className="w-full px-3 py-3 rounded-xl bg-white border border-[#123C32]/15 text-sm"
                    >
                      <option value="Live Certified">Live Certified</option>
                      <option value="Cold-Chain">Cold-Chain (0–4°C)</option>
                      <option value="Standard">Standard Pack</option>
                    </select>
                  </div>
                </div>

                {/* Pack Size & Breed / Variant */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold uppercase text-[#123C32] block mb-1">
                      Pack Size / Weight
                    </label>
                    <input
                      required
                      value={formPackSize}
                      onChange={(e) => setFormPackSize(e.target.value)}
                      placeholder="e.g. 500g / 12 Eggs"
                      className="w-full px-3.5 py-3 rounded-xl bg-white border border-[#123C32]/15 text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold uppercase text-[#123C32] block mb-1">
                      Breed / Variant Type
                    </label>
                    <input
                      required
                      value={formVariantType}
                      onChange={(e) => setFormVariantType(e.target.value)}
                      placeholder="e.g. Kadaknath / Boneless"
                      className="w-full px-3.5 py-3 rounded-xl bg-white border border-[#123C32]/15 text-sm"
                    />
                  </div>
                </div>

                {/* Pricing & Stock */}
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-bold uppercase text-[#123C32] block mb-1">
                      Selling ₹
                    </label>
                    <input
                      type="number"
                      required
                      value={formPrice}
                      onChange={(e) => setFormPrice(e.target.value)}
                      placeholder="899"
                      className="w-full px-3 py-3 rounded-xl bg-white border border-[#123C32]/15 text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold uppercase text-[#123C32] block mb-1">
                      MRP ₹
                    </label>
                    <input
                      type="number"
                      required
                      value={formMrp}
                      onChange={(e) => setFormMrp(e.target.value)}
                      placeholder="1199"
                      className="w-full px-3 py-3 rounded-xl bg-white border border-[#123C32]/15 text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold uppercase text-[#123C32] block mb-1">
                      Stock Qty
                    </label>
                    <input
                      type="number"
                      required
                      value={formStock}
                      onChange={(e) => setFormStock(e.target.value)}
                      placeholder="50"
                      className="w-full px-3 py-3 rounded-xl bg-white border border-[#123C32]/15 text-sm"
                    />
                  </div>
                </div>

                {/* Product Description */}
                <div>
                  <label className="text-xs font-bold uppercase text-[#123C32] block mb-1">
                    Product Details & Storage Info
                  </label>
                  <textarea
                    rows={3}
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    placeholder="Add freshness details, storage instructions, or ingredients..."
                    className="w-full px-4 py-3 rounded-xl bg-white border border-[#123C32]/15 text-sm"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-[#123C32] text-[#F7F5EF] font-bold text-sm shadow-lg hover:bg-[#1a5244] transition-all mt-2"
                >
                  {editingProductId
                    ? "Save Product Changes"
                    : "Publish Product"}
                </button>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}