// "use client";

// import { useStore } from "@/components/StoreProvider";

// export default function Page() {
//   const { customers, orders } = useStore();

//   return (
//     <div>
//       <p className="eyebrow">Relationships</p>
//       <h1 className="section-title mt-2">Customers</h1>
//       <p className="mt-3 text-sm text-charcoal/60">
//         Customer contact and delivery details are saved when they sign in or place an order.
//       </p>
//       <p className="mt-2 text-xs leading-5 text-charcoal/50">
//         This demo stores records in this browser only. Use protected server-side storage before handling customer data in production.
//       </p>
//       <div className="mt-5 space-y-3">
//         {customers.map((customer) => {
//           const customerOrders = orders.filter((order) =>
//             order.customerId === customer.id
//             || order.customerEmail?.toLowerCase() === customer.email.toLowerCase(),
//           );
//           const latestAddress = customerOrders.find((order) => order.customerAddress)?.customerAddress;

//           return (
//             <article key={customer.id} className="rounded-2xl bg-white p-5">
//               <div className="flex flex-wrap items-start justify-between gap-3">
//                 <div>
//                   <h2 className="font-serif text-xl text-forest">{customer.fullName}</h2>
//                   <p className="mt-1 break-all text-sm text-charcoal/65">{customer.email}</p>
//                 </div>
//                 <span className="rounded-full bg-sage px-3 py-1 text-xs font-medium text-forest">
//                   {customerOrders.length} {customerOrders.length === 1 ? "order" : "orders"}
//                 </span>
//               </div>
//               <dl className="mt-4 grid gap-3 border-t border-forest/10 pt-4 text-sm sm:grid-cols-2">
//                 <div><dt className="text-xs text-charcoal/50">Phone</dt><dd className="mt-1 break-words">{customer.phone || "Not provided"}</dd></div>
//                 <div><dt className="text-xs text-charcoal/50">Delivery address</dt><dd className="mt-1 whitespace-pre-wrap break-words">{customer.address || latestAddress || "Not provided"}</dd></div>
//                 <div><dt className="text-xs text-charcoal/50">Customer since</dt><dd className="mt-1">{new Date(customer.createdAt).toLocaleDateString()}</dd></div>
//                 <div><dt className="text-xs text-charcoal/50">Last seen</dt><dd className="mt-1">{new Date(customer.lastSeenAt).toLocaleDateString()}</dd></div>
//               </dl>
//               {customerOrders.length > 0 && (
//                 <div className="mt-4 border-t border-forest/10 pt-4">
//                   <h3 className="text-xs font-semibold uppercase tracking-wide text-charcoal/55">Recent orders</h3>
//                   <ul className="mt-2 space-y-1 text-sm">
//                     {customerOrders.slice(0, 3).map((order) => (
//                       <li key={order.id} className="flex flex-wrap justify-between gap-2">
//                         <span>{order.id} · {new Date(order.date).toLocaleDateString()}</span>
//                         <span className="capitalize text-charcoal/60">{order.status}</span>
//                       </li>
//                     ))}
//                   </ul>
//                 </div>
//               )}
//             </article>
//           );
//         })}
//       </div>
//       {!customers.length && (
//         <p className="mt-5 rounded-2xl bg-white p-6 text-sm text-charcoal/60">
//           No customers saved in this browser yet. Customer profiles will appear here after sign-in.
//         </p>
//       )}
//     </div>
//   );
// }



"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { Search, UserCheck, Mail, Phone, ShoppingBag } from "lucide-react";

const CUSTOMERS = [
  {
    id: "c1",
    name: "Rajesh Verma",
    email: "rajesh.verma@example.com",
    phone: "+91 98112 34567",
    joined: "12 Aug 2026",
    ordersCount: 14,
    ltv: 28450,
    status: "Active",
  },
  {
    id: "c2",
    name: "Ananya Sharma",
    email: "ananya.s@example.com",
    phone: "+91 98765 11223",
    joined: "04 Sep 2026",
    ordersCount: 8,
    ltv: 9640,
    status: "Active",
  },
  {
    id: "c3",
    name: "GreenValley Poultry Farm",
    email: "procurement@greenvalley.in",
    phone: "+91 99100 88776",
    joined: "19 Jul 2026",
    ordersCount: 23,
    ltv: 142800,
    status: "Wholesale VIP",
  },
];

export default function AdminCustomersPage() {
  const [query, setQuery] = useState("");

  const filtered = CUSTOMERS.filter(
    (c) =>
      c.name.toLowerCase().includes(query.toLowerCase()) ||
      c.email.toLowerCase().includes(query.toLowerCase()) ||
      c.phone.includes(query)
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-[0.18em] text-[#123C32]/60">
            Buyer & Farm Accounts
          </span>
          <h1 className="font-serif text-2xl sm:text-4xl font-bold text-[#123C32] mt-1">
            Customer Directory
          </h1>
        </div>

        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-[#123C32]/45 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search name, email or phone..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white border border-[#123C32]/15 text-sm focus:outline-none"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map((cust, idx) => (
          <motion.div
            key={cust.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.06 }}
            whileHover={{ y: -4 }}
            className="bg-white rounded-3xl p-6 border border-[#123C32]/10 shadow-sm hover:shadow-xl transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#123C32] text-[#D9A65A] font-serif text-xl font-bold flex items-center justify-center">
                  {cust.name.charAt(0)}
                </div>
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#E5EDE6] text-[#123C32] text-xs font-bold">
                  <UserCheck className="w-3.5 h-3.5" /> {cust.status}
                </span>
              </div>

              <h3 className="font-serif text-xl font-bold text-[#123C32] mt-4">
                {cust.name}
              </h3>
              <div className="mt-2 space-y-1 text-xs text-[#202824]/70">
                <p className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-[#123C32]" /> {cust.email}
                </p>
                <p className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-[#123C32]" /> {cust.phone}
                </p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#123C32]/10 flex items-center justify-between">
              <div>
                <span className="text-[11px] uppercase text-[#202824]/50 block">
                  Lifetime Value
                </span>
                <span className="font-extrabold text-base text-[#123C32]">
                  ₹{cust.ltv.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[11px] uppercase text-[#202824]/50 block">
                  Total Orders
                </span>
                <span className="inline-flex items-center gap-1 font-bold text-sm text-[#202824]">
                  <ShoppingBag className="w-3.5 h-3.5 text-[#D9A65A]" />
                  {cust.ordersCount}
                </span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}